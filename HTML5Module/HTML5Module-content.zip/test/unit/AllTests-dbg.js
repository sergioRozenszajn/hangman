sap.ui.define([
	"ns/HTML5Module/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
